#pragma once
class Usecka
{
public:
	Usecka();
	~Usecka();
};

