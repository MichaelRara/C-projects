#include "Usecka.h"



Usecka::Usecka()
{
}


Usecka::~Usecka()
{
}
